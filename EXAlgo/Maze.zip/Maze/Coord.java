
// Coord.java
// Andrew Davison, ad@fivedots.coe.psu.ac.th, Jan 2021

//        **** DO NOT CHANGE THIS CODE ****


public class Coord
{
  private int x, y;

  public Coord(int x, int y)
  { this.x = x;
    this.y = y;
  }

  public int getX()
  {  return x; }

  public int getY()
  {  return y; }

}  // end of Coord class
